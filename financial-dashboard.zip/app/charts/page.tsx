"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import RevenueExpenseChart from "@/components/revenue-expense-chart"
import CashFlowChart from "@/components/cash-flow-chart"
import ProfitMarginChart from "@/components/profit-margin-chart"
import SalesDistributionChart from "@/components/sales-distribution-chart"
import ExpenseCategoryChart from "@/components/expense-category-chart"
import { getChartData } from "@/lib/financial-data"

export default function ChartsPage() {
  const [activeTab, setActiveTab] = useState("revenue")
  const [period, setPeriod] = useState("6m")
  const [chartData, setChartData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function loadChartData() {
      setLoading(true)
      setError(null)

      try {
        const data = await getChartData(activeTab, period)
        setChartData(data)
      } catch (err) {
        console.error("Erro ao carregar dados do gráfico:", err)
        setError("Não foi possível carregar os dados do gráfico. Tente novamente.")
      } finally {
        setLoading(false)
      }
    }

    loadChartData()
  }, [activeTab, period])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Gráficos Financeiros</h1>

      <div className="flex justify-end mb-4">
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Selecione o período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="3m">Últimos 3 meses</SelectItem>
            <SelectItem value="6m">Últimos 6 meses</SelectItem>
            <SelectItem value="1y">Último ano</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="revenue" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
          <TabsTrigger value="revenue">Receitas</TabsTrigger>
          <TabsTrigger value="expenses">Despesas</TabsTrigger>
          <TabsTrigger value="profit">Lucros</TabsTrigger>
          <TabsTrigger value="cash-flow">Fluxo de Caixa</TabsTrigger>
          <TabsTrigger value="distribution">Distribuição</TabsTrigger>
        </TabsList>

        {loading ? (
          <div className="flex justify-center items-center h-96">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <Card>
            <CardContent className="p-6 text-center text-destructive">{error}</CardContent>
          </Card>
        ) : (
          <>
            <TabsContent value="revenue" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Evolução de Receitas</CardTitle>
                  <CardDescription>Análise mensal de receitas por categoria</CardDescription>
                </CardHeader>
                <CardContent className="h-96">
                  <RevenueExpenseChart data={chartData} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="expenses" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Análise de Despesas</CardTitle>
                  <CardDescription>Detalhamento das categorias de despesas</CardDescription>
                </CardHeader>
                <CardContent className="h-96">
                  <ExpenseCategoryChart data={chartData} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="profit" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Margem de Lucro</CardTitle>
                  <CardDescription>Evolução da margem de lucro ao longo do tempo</CardDescription>
                </CardHeader>
                <CardContent className="h-96">
                  <ProfitMarginChart data={chartData} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="cash-flow" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Fluxo de Caixa</CardTitle>
                  <CardDescription>Entradas e saídas de caixa por período</CardDescription>
                </CardHeader>
                <CardContent className="h-96">
                  <CashFlowChart data={chartData} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="distribution" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Distribuição de Vendas</CardTitle>
                  <CardDescription>Distribuição de vendas por categoria de produto</CardDescription>
                </CardHeader>
                <CardContent className="h-96">
                  <SalesDistributionChart data={chartData} />
                </CardContent>
              </Card>
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  )
}

