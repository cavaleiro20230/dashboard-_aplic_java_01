import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import FinancialOverview from "@/components/financial-overview"
import RevenueExpenseChart from "@/components/revenue-expense-chart"
import CashFlowChart from "@/components/cash-flow-chart"
import ProfitMarginChart from "@/components/profit-margin-chart"
import { getDashboardData } from "@/lib/financial-data"
import DashboardSkeleton from "@/components/dashboard-skeleton"

export default async function DashboardPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Painel de Controle Financeiro</h1>

      <Suspense fallback={<DashboardSkeleton />}>
        <DashboardContent />
      </Suspense>
    </div>
  )
}

async function DashboardContent() {
  const { indicators, overviewData } = await getDashboardData()

  // Calcular a margem de lucro
  const margemLucro =
    indicators.receita_total > 0 ? ((indicators.lucro_liquido / indicators.receita_total) * 100).toFixed(1) : "0.0"

  return (
    <Tabs defaultValue="overview" className="space-y-4">
      <TabsList>
        <TabsTrigger value="overview">Visão Geral</TabsTrigger>
        <TabsTrigger value="revenue">Receitas</TabsTrigger>
        <TabsTrigger value="expenses">Despesas</TabsTrigger>
        <TabsTrigger value="profit">Lucros</TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                  indicators.receita_total,
                )}
              </div>
              <p className="text-xs text-muted-foreground">+20.1% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                  indicators.despesas_total,
                )}
              </div>
              <p className="text-xs text-muted-foreground">+4.3% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Lucro Líquido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                  indicators.lucro_liquido,
                )}
              </div>
              <p className="text-xs text-muted-foreground">+28.4% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Margem de Lucro</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{margemLucro}%</div>
              <p className="text-xs text-muted-foreground">+5.1% em relação ao mês anterior</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <Card className="col-span-4">
            <CardHeader>
              <CardTitle>Visão Geral Financeira</CardTitle>
            </CardHeader>
            <CardContent className="pl-2">
              <FinancialOverview data={overviewData} />
            </CardContent>
          </Card>
          <Card className="col-span-3">
            <CardHeader>
              <CardTitle>Receitas vs Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <RevenueExpenseChart />
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="revenue" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Análise de Receitas</CardTitle>
            <CardDescription>Detalhamento das fontes de receita</CardDescription>
          </CardHeader>
          <CardContent className="h-96">
            <RevenueExpenseChart />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="expenses" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Análise de Despesas</CardTitle>
            <CardDescription>Detalhamento das categorias de despesas</CardDescription>
          </CardHeader>
          <CardContent className="h-96">
            <CashFlowChart />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="profit" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Análise de Lucros</CardTitle>
            <CardDescription>Evolução da margem de lucro</CardDescription>
          </CardHeader>
          <CardContent className="h-96">
            <ProfitMarginChart />
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}

