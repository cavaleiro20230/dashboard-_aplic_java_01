"use client"

import { useState, useEffect } from "react"
import { Download, Filter, Printer, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DateRangePicker } from "@/components/date-range-picker"
import { getReportData } from "@/lib/financial-data"

export default function ReportsPage() {
  const [reportType, setReportType] = useState("income-statement")
  const [dateRange, setDateRange] = useState({
    from: new Date(new Date().getFullYear(), 0, 1),
    to: new Date(),
  })
  const [reportData, setReportData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function loadReportData() {
      setLoading(true)
      setError(null)

      try {
        const startDate = dateRange.from.toISOString()
        const endDate = dateRange.to.toISOString()

        const data = await getReportData(reportType, startDate, endDate)
        setReportData(data)
      } catch (err) {
        console.error("Erro ao carregar relatório:", err)
        setError("Não foi possível carregar os dados do relatório. Tente novamente.")
      } finally {
        setLoading(false)
      }
    }

    loadReportData()
  }, [reportType, dateRange])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Relatórios Financeiros</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Card className="w-full md:w-64">
          <CardHeader>
            <CardTitle className="text-lg">Tipo de Relatório</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um relatório" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="income-statement">Demonstração de Resultados</SelectItem>
                <SelectItem value="balance-sheet">Balanço Patrimonial</SelectItem>
                <SelectItem value="cash-flow">Fluxo de Caixa</SelectItem>
                <SelectItem value="tax-report">Relatório Fiscal</SelectItem>
                <SelectItem value="accounts-receivable">Contas a Receber</SelectItem>
                <SelectItem value="accounts-payable">Contas a Pagar</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="w-full md:flex-1">
          <CardHeader>
            <CardTitle className="text-lg">Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <DateRangePicker value={dateRange} onChange={setDateRange} />

              <div className="flex gap-2">
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Printer className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : error ? (
        <Card>
          <CardContent className="p-6 text-center text-destructive">{error}</CardContent>
        </Card>
      ) : (
        <>
          {reportType === "income-statement" && <IncomeStatementReport data={reportData} dateRange={dateRange} />}

          {reportType === "balance-sheet" && <BalanceSheetReport data={reportData} dateRange={dateRange} />}

          {reportType === "cash-flow" && <CashFlowReport data={reportData} dateRange={dateRange} />}
        </>
      )}
    </div>
  )
}

function IncomeStatementReport({ data, dateRange }) {
  // Agrupar dados por mês
  const months = [...new Set(data.map((item) => item.mes))]

  // Formatar datas para exibição
  const fromDate = dateRange.from.toLocaleDateString("pt-BR")
  const toDate = dateRange.to.toLocaleDateString("pt-BR")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Demonstração de Resultados</CardTitle>
        <CardDescription>
          Período: {fromDate} - {toDate}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[300px]">Descrição</TableHead>
              {months.map((month) => (
                <TableHead key={month}>{month}</TableHead>
              ))}
              <TableHead>Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {/* Renderizar linhas com base nos dados do banco */}
            {/* Este é um exemplo simplificado - você precisará adaptar conforme sua estrutura de dados */}
            <TableRow className="font-medium">
              <TableCell>Receita Bruta</TableCell>
              {months.map((month) => {
                const monthData = data.filter((item) => item.mes === month)
                const total = monthData.reduce((sum, item) => sum + (item.receita || 0), 0)
                return (
                  <TableCell key={month}>
                    {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(total)}
                  </TableCell>
                )
              })}
              <TableCell>
                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                  data.reduce((sum, item) => sum + (item.receita || 0), 0),
                )}
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell>(-) Deduções</TableCell>
              {months.map((month) => {
                const monthData = data.filter((item) => item.mes === month)
                const deductions = monthData.reduce((sum, item) => sum + (item.receita || 0) * 0.18, 0)
                return (
                  <TableCell key={month}>
                    {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(deductions)}
                  </TableCell>
                )
              })}
              <TableCell>
                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                  data.reduce((sum, item) => sum + (item.receita || 0) * 0.18, 0),
                )}
              </TableCell>
            </TableRow>

            <TableRow className="font-medium">
              <TableCell>Receita Líquida</TableCell>
              {months.map((month) => {
                const monthData = data.filter((item) => item.mes === month)
                const total = monthData.reduce((sum, item) => sum + (item.receita || 0), 0)
                const deductions = total * 0.18
                return (
                  <TableCell key={month}>
                    {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(total - deductions)}
                  </TableCell>
                )
              })}
              <TableCell>
                {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                  data.reduce((sum, item) => sum + (item.receita || 0) * 0.82, 0),
                )}
              </TableCell>
            </TableRow>

            {/* Adicione mais linhas conforme necessário */}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

function BalanceSheetReport({ data, dateRange }) {
  // Agrupar dados por tipo de conta
  const ativo = data.filter((item) => item.tipo_conta === "ativo")
  const passivo = data.filter((item) => item.tipo_conta === "passivo" || item.tipo_conta === "patrimonio")

  // Formatar data para exibição
  const reportDate = dateRange.to.toLocaleDateString("pt-BR")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Balanço Patrimonial</CardTitle>
        <CardDescription>Data: {reportDate}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-bold mb-4">Ativo</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">Descrição</TableHead>
                  <TableHead>Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ativo.length > 0 ? (
                  <>
                    <TableRow className="font-medium">
                      <TableCell>Ativo Circulante</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          ativo
                            .filter((item) => item.categoria.includes("circulante"))
                            .reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                    {ativo
                      .filter((item) => item.categoria.includes("circulante"))
                      .map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="pl-6">{item.categoria}</TableCell>
                          <TableCell>
                            {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.valor)}
                          </TableCell>
                        </TableRow>
                      ))}
                    <TableRow className="font-medium">
                      <TableCell>Ativo Não Circulante</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          ativo
                            .filter((item) => !item.categoria.includes("circulante"))
                            .reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                    {ativo
                      .filter((item) => !item.categoria.includes("circulante"))
                      .map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="pl-6">{item.categoria}</TableCell>
                          <TableCell>
                            {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.valor)}
                          </TableCell>
                        </TableRow>
                      ))}
                    <TableRow className="font-medium text-lg">
                      <TableCell>Total do Ativo</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          ativo.reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                  </>
                ) : (
                  <TableRow>
                    <TableCell colSpan={2} className="text-center">
                      Nenhum dado disponível
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Passivo e Patrimônio Líquido</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">Descrição</TableHead>
                  <TableHead>Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {passivo.length > 0 ? (
                  <>
                    <TableRow className="font-medium">
                      <TableCell>Passivo Circulante</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          passivo
                            .filter((item) => item.categoria.includes("circulante"))
                            .reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                    {passivo
                      .filter((item) => item.categoria.includes("circulante"))
                      .map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="pl-6">{item.categoria}</TableCell>
                          <TableCell>
                            {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.valor)}
                          </TableCell>
                        </TableRow>
                      ))}
                    <TableRow className="font-medium">
                      <TableCell>Passivo Não Circulante</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          passivo
                            .filter((item) => item.tipo_conta === "passivo" && !item.categoria.includes("circulante"))
                            .reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                    {passivo
                      .filter((item) => item.tipo_conta === "passivo" && !item.categoria.includes("circulante"))
                      .map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="pl-6">{item.categoria}</TableCell>
                          <TableCell>
                            {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.valor)}
                          </TableCell>
                        </TableRow>
                      ))}
                    <TableRow className="font-medium">
                      <TableCell>Patrimônio Líquido</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          passivo
                            .filter((item) => item.tipo_conta === "patrimonio")
                            .reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                    {passivo
                      .filter((item) => item.tipo_conta === "patrimonio")
                      .map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="pl-6">{item.categoria}</TableCell>
                          <TableCell>
                            {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.valor)}
                          </TableCell>
                        </TableRow>
                      ))}
                    <TableRow className="font-medium text-lg">
                      <TableCell>Total do Passivo e PL</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                          passivo.reduce((sum, item) => sum + item.valor, 0),
                        )}
                      </TableCell>
                    </TableRow>
                  </>
                ) : (
                  <TableRow>
                    <TableCell colSpan={2} className="text-center">
                      Nenhum dado disponível
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function CashFlowReport({ data, dateRange }) {
  // Formatar datas para exibição
  const fromDate = dateRange.from.toLocaleDateString("pt-BR")
  const toDate = dateRange.to.toLocaleDateString("pt-BR")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Fluxo de Caixa</CardTitle>
        <CardDescription>
          Período: {fromDate} - {toDate}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Mês</TableHead>
              <TableHead>Entradas</TableHead>
              <TableHead>Saídas</TableHead>
              <TableHead>Saldo</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length > 0 ? (
              <>
                {data.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.mes}</TableCell>
                    <TableCell>
                      {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.entradas)}
                    </TableCell>
                    <TableCell>
                      {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.saidas)}
                    </TableCell>
                    <TableCell>
                      {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(item.saldo)}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="font-medium">
                  <TableCell>Total</TableCell>
                  <TableCell>
                    {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                      data.reduce((sum, item) => sum + item.entradas, 0),
                    )}
                  </TableCell>
                  <TableCell>
                    {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                      data.reduce((sum, item) => sum + item.saidas, 0),
                    )}
                  </TableCell>
                  <TableCell>
                    {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
                      data.reduce((sum, item) => sum + item.saldo, 0),
                    )}
                  </TableCell>
                </TableRow>
              </>
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center">
                  Nenhum dado disponível
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

