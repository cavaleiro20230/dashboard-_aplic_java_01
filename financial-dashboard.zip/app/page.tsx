import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-primary text-primary-foreground py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">Sistema Financeiro</h1>
          <p className="mt-2">Relatórios e gráficos detalhados para análise financeira</p>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Painel de Controle</CardTitle>
              <CardDescription>Visão geral dos dados financeiros</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center justify-center bg-muted rounded-md">
                <p className="text-muted-foreground">Resumo de indicadores financeiros</p>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/dashboard" className="w-full">
                <Button className="w-full">
                  Acessar Painel
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Relatórios</CardTitle>
              <CardDescription>Relatórios financeiros detalhados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center justify-center bg-muted rounded-md">
                <p className="text-muted-foreground">Relatórios personalizáveis</p>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/reports" className="w-full">
                <Button className="w-full">
                  Ver Relatórios
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Gráficos</CardTitle>
              <CardDescription>Visualização gráfica dos dados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-center justify-center bg-muted rounded-md">
                <p className="text-muted-foreground">Gráficos interativos</p>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/charts" className="w-full">
                <Button className="w-full">
                  Ver Gráficos
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </main>

      <footer className="bg-muted py-6">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>© 2024 Sistema Financeiro. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  )
}

