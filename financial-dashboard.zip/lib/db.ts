import sql from "mssql"

// Configuração de conexão com o SQL Server
const sqlConfig = {
  user: process.env.DB_USER || "",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "",
  server: process.env.DB_SERVER || "",
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true, // Para conexões Azure
    trustServerCertificate: true, // Mudar para false em produção
  },
}

// Função para conectar ao banco de dados
export async function getConnection() {
  try {
    const pool = await sql.connect(sqlConfig)
    return pool
  } catch (err) {
    console.error("Erro ao conectar ao banco de dados:", err)
    throw new Error("Falha na conexão com o banco de dados")
  }
}

// Função para executar consultas SQL
export async function executeQuery(query: string, params: any[] = []) {
  try {
    const pool = await getConnection()
    const request = pool.request()

    // Adiciona parâmetros à consulta
    params.forEach((param, index) => {
      request.input(`param${index}`, param)
    })

    const result = await request.query(query)
    return result.recordset
  } catch (err) {
    console.error("Erro ao executar consulta:", err)
    throw new Error("Falha ao executar consulta no banco de dados")
  }
}

