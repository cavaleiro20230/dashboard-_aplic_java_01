import { executeQuery } from "./db"

// Função para buscar dados do dashboard
export async function getDashboardData() {
  try {
    // Buscar indicadores financeiros
    const indicators = await executeQuery(`
      SELECT 
        SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) as receita_total,
        SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) as despesas_total,
        SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END) as lucro_liquido
      FROM transacoes 
      WHERE data_transacao >= DATEADD(month, -1, GETDATE())
    `)

    // Buscar dados para o gráfico de visão geral
    const overviewData = await executeQuery(`
      SELECT 
        FORMAT(data_transacao, 'MMM') as mes,
        SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) as receita,
        SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) as despesas,
        SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END) as lucro
      FROM transacoes
      WHERE data_transacao >= DATEADD(month, -6, GETDATE())
      GROUP BY FORMAT(data_transacao, 'MMM'), MONTH(data_transacao)
      ORDER BY MONTH(data_transacao)
    `)

    return {
      indicators: indicators[0] || { receita_total: 0, despesas_total: 0, lucro_liquido: 0 },
      overviewData,
    }
  } catch (error) {
    console.error("Erro ao buscar dados do dashboard:", error)
    throw new Error("Falha ao carregar dados do dashboard")
  }
}

// Função para buscar dados de relatórios
export async function getReportData(reportType: string, startDate: string, endDate: string) {
  try {
    let query = ""

    if (reportType === "income-statement") {
      query = `
        SELECT 
          FORMAT(data_transacao, 'MMM') as mes,
          categoria,
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) as receita,
          SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) as despesa,
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END) as lucro
        FROM transacoes
        WHERE data_transacao BETWEEN @param0 AND @param1
        GROUP BY FORMAT(data_transacao, 'MMM'), MONTH(data_transacao), categoria
        ORDER BY MONTH(data_transacao), categoria
      `
    } else if (reportType === "balance-sheet") {
      query = `
        SELECT 
          categoria,
          tipo_conta,
          SUM(valor) as valor
        FROM contas
        WHERE data_referencia <= @param1
        GROUP BY categoria, tipo_conta
        ORDER BY tipo_conta, categoria
      `
    } else if (reportType === "cash-flow") {
      query = `
        SELECT 
          FORMAT(data_transacao, 'MMM') as mes,
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) as entradas,
          SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) as saidas,
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END) as saldo
        FROM transacoes
        WHERE data_transacao BETWEEN @param0 AND @param1
        GROUP BY FORMAT(data_transacao, 'MMM'), MONTH(data_transacao)
        ORDER BY MONTH(data_transacao)
      `
    }

    const data = await executeQuery(query, [startDate, endDate])
    return data
  } catch (error) {
    console.error("Erro ao buscar dados de relatório:", error)
    throw new Error("Falha ao carregar dados do relatório")
  }
}

// Função para buscar dados de gráficos
export async function getChartData(chartType: string, period = "6m") {
  try {
    let query = ""
    const params = []

    // Determinar a data de início com base no período
    const startDate = new Date()
    if (period === "6m") {
      startDate.setMonth(startDate.getMonth() - 6)
    } else if (period === "1y") {
      startDate.setFullYear(startDate.getFullYear() - 1)
    } else if (period === "3m") {
      startDate.setMonth(startDate.getMonth() - 3)
    }

    params.push(startDate.toISOString())

    if (chartType === "revenue") {
      query = `
        SELECT 
          FORMAT(data_transacao, 'MMM') as month,
          SUM(valor) as receita
        FROM transacoes
        WHERE tipo = 'receita' AND data_transacao >= @param0
        GROUP BY FORMAT(data_transacao, 'MMM'), MONTH(data_transacao)
        ORDER BY MONTH(data_transacao)
      `
    } else if (chartType === "expenses") {
      query = `
        SELECT 
          categoria as name,
          SUM(valor) as value
        FROM transacoes
        WHERE tipo = 'despesa' AND data_transacao >= @param0
        GROUP BY categoria
        ORDER BY SUM(valor) DESC
      `
    } else if (chartType === "profit") {
      query = `
        SELECT 
          FORMAT(data_transacao, 'MMM') as month,
          (SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) - 
           SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END)) / 
           NULLIF(SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END), 0) * 100 as margem
        FROM transacoes
        WHERE data_transacao >= @param0
        GROUP BY FORMAT(data_transacao, 'MMM'), MONTH(data_transacao)
        ORDER BY MONTH(data_transacao)
      `
    } else if (chartType === "cash-flow") {
      query = `
        SELECT 
          FORMAT(data_transacao, 'MMM') as month,
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) as entradas,
          SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) as saidas,
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END) as saldo
        FROM transacoes
        WHERE data_transacao >= @param0
        GROUP BY FORMAT(data_transacao, 'MMM'), MONTH(data_transacao)
        ORDER BY MONTH(data_transacao)
      `
    } else if (chartType === "distribution") {
      query = `
        SELECT 
          categoria as name,
          SUM(valor) as value
        FROM transacoes
        WHERE tipo = 'receita' AND data_transacao >= @param0
        GROUP BY categoria
        ORDER BY SUM(valor) DESC
      `
    }

    const data = await executeQuery(query, params)
    return data
  } catch (error) {
    console.error("Erro ao buscar dados de gráfico:", error)
    throw new Error("Falha ao carregar dados do gráfico")
  }
}

