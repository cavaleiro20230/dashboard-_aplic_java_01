"use client"

import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface RevenueExpenseChartProps {
  data?: any[]
}

export default function RevenueExpenseChart({ data = [] }: RevenueExpenseChartProps) {
  // Usar dados do banco ou dados de fallback se estiver vazio
  const chartData =
    data.length > 0
      ? data
      : [
          { month: "Jan", receita: 120000, despesas: 63600 },
          { month: "Fev", receita: 135000, despesas: 71550 },
          { month: "Mar", receita: 142500, despesas: 75525 },
          { month: "Abr", receita: 150000, despesas: 79500 },
          { month: "Mai", receita: 157500, despesas: 83475 },
          { month: "Jun", receita: 165000, despesas: 87450 },
        ]

  return (
    <ChartContainer
      config={{
        receita: {
          label: "Receita",
          color: "hsl(var(--chart-1))",
        },
        despesas: {
          label: "Despesas",
          color: "hsl(var(--chart-2))",
        },
      }}
      className="h-[300px]"
    >
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="month" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Bar dataKey="receita" fill="var(--color-receita)" radius={[4, 4, 0, 0]} />
        <Bar dataKey="despesas" fill="var(--color-despesas)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ChartContainer>
  )
}

