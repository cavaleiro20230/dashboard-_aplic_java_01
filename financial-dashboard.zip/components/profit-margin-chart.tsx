"use client"

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { month: "Jan", margem: 47 },
  { month: "Fev", margem: 47.5 },
  { month: "Mar", margem: 47.8 },
  { month: "Abr", margem: 48.2 },
  { month: "Mai", margem: 48.5 },
  { month: "Jun", margem: 49 },
]

export default function ProfitMarginChart() {
  return (
    <ChartContainer
      config={{
        margem: {
          label: "Margem de Lucro (%)",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis domain={[40, 55]} />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Area
          type="monotone"
          dataKey="margem"
          stroke="var(--color-margem)"
          fill="var(--color-margem)"
          fillOpacity={0.3}
        />
      </AreaChart>
    </ChartContainer>
  )
}

