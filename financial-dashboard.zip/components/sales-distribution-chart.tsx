"use client"

import { Cell, Pie, PieChart } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { name: "Produtos Eletrônicos", value: 35 },
  { name: "Móveis", value: 25 },
  { name: "Roupas", value: 20 },
  { name: "Acessórios", value: 15 },
  { name: "Outros", value: 5 },
]

export default function SalesDistributionChart() {
  return (
    <ChartContainer
      config={{
        "Produtos Eletrônicos": {
          label: "Produtos Eletrônicos",
          color: "hsl(var(--chart-1))",
        },
        Móveis: {
          label: "Móveis",
          color: "hsl(var(--chart-2))",
        },
        Roupas: {
          label: "Roupas",
          color: "hsl(var(--chart-3))",
        },
        Acessórios: {
          label: "Acessórios",
          color: "hsl(var(--chart-4))",
        },
        Outros: {
          label: "Outros",
          color: "hsl(var(--chart-5))",
        },
      }}
      className="h-[300px]"
    >
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" labelLine={false} outerRadius={120} fill="#8884d8" dataKey="value">
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={`var(--color-${entry.name.replace(/\s+/g, "-")})`} />
          ))}
        </Pie>
        <ChartTooltip content={<ChartTooltipContent />} />
      </PieChart>
    </ChartContainer>
  )
}

