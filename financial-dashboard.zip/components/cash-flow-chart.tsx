"use client"

import { Line, LineChart, CartesianGrid, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { month: "Jan", entradas: 120000, saidas: 63600, saldo: 56400 },
  { month: "Fev", entradas: 135000, saidas: 71550, saldo: 63450 },
  { month: "Mar", entradas: 142500, saidas: 75525, saldo: 66975 },
  { month: "Abr", entradas: 150000, saidas: 79500, saldo: 70500 },
  { month: "Mai", entradas: 157500, saidas: 83475, saldo: 74025 },
  { month: "Jun", entradas: 165000, saidas: 87450, saldo: 77550 },
]

export default function CashFlowChart() {
  return (
    <ChartContainer
      config={{
        entradas: {
          label: "Entradas",
          color: "hsl(var(--chart-1))",
        },
        saidas: {
          label: "Saídas",
          color: "hsl(var(--chart-2))",
        },
        saldo: {
          label: "Saldo",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Line type="monotone" dataKey="entradas" stroke="var(--color-entradas)" strokeWidth={2} />
        <Line type="monotone" dataKey="saidas" stroke="var(--color-saidas)" strokeWidth={2} />
        <Line type="monotone" dataKey="saldo" stroke="var(--color-saldo)" strokeWidth={3} />
      </LineChart>
    </ChartContainer>
  )
}

