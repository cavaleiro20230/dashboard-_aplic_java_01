"use client"

import { Cell, Pie, PieChart } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { name: "Custos de Produtos", value: 45 },
  { name: "Salários", value: 25 },
  { name: "Marketing", value: 15 },
  { name: "Infraestrutura", value: 10 },
  { name: "Outros", value: 5 },
]

export default function ExpenseCategoryChart() {
  return (
    <ChartContainer
      config={{
        "Custos de Produtos": {
          label: "Custos de Produtos",
          color: "hsl(var(--chart-1))",
        },
        Salários: {
          label: "Salários",
          color: "hsl(var(--chart-2))",
        },
        Marketing: {
          label: "Marketing",
          color: "hsl(var(--chart-3))",
        },
        Infraestrutura: {
          label: "Infraestrutura",
          color: "hsl(var(--chart-4))",
        },
        Outros: {
          label: "Outros",
          color: "hsl(var(--chart-5))",
        },
      }}
      className="h-[300px]"
    >
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" labelLine={false} outerRadius={120} fill="#8884d8" dataKey="value">
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={`var(--color-${entry.name.replace(/\s+/g, "-")})`} />
          ))}
        </Pie>
        <ChartTooltip content={<ChartTooltipContent />} />
      </PieChart>
    </ChartContainer>
  )
}

