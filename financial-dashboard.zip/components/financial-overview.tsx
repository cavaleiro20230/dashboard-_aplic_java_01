"use client"

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface FinancialOverviewProps {
  data: any[]
}

export default function FinancialOverview({ data = [] }: FinancialOverviewProps) {
  // Usar dados do banco ou dados de fallback se estiver vazio
  const chartData =
    data.length > 0
      ? data
      : [
          { mes: "Jan", receita: 120000, despesas: 63600, lucro: 56400 },
          { mes: "Fev", receita: 135000, despesas: 71550, lucro: 63450 },
          { mes: "Mar", receita: 142500, despesas: 75525, lucro: 66975 },
          { mes: "Abr", receita: 150000, despesas: 79500, lucro: 70500 },
          { mes: "Mai", receita: 157500, despesas: 83475, lucro: 74025 },
          { mes: "Jun", receita: 165000, despesas: 87450, lucro: 77550 },
        ]

  return (
    <ChartContainer
      config={{
        receita: {
          label: "Receita",
          color: "hsl(var(--chart-1))",
        },
        despesas: {
          label: "Despesas",
          color: "hsl(var(--chart-2))",
        },
        lucro: {
          label: "Lucro",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="mes" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Area
          type="monotone"
          dataKey="receita"
          stroke="var(--color-receita)"
          fill="var(--color-receita)"
          fillOpacity={0.3}
        />
        <Area
          type="monotone"
          dataKey="despesas"
          stroke="var(--color-despesas)"
          fill="var(--color-despesas)"
          fillOpacity={0.3}
        />
        <Area type="monotone" dataKey="lucro" stroke="var(--color-lucro)" fill="var(--color-lucro)" fillOpacity={0.3} />
      </AreaChart>
    </ChartContainer>
  )
}

